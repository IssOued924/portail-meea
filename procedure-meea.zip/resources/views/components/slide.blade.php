<section id="hero">
    <div class="hero-container">
      <div id="hero">
        <div class=" " role="listbox">
          <!-- Slide 1 -->
          <div class="carousel-item active" style="background-image: url(img/slide/header.png)">

                <div class="col-lg-6 offset-lg-3 animate__animated animate__fadeInUp">
                 <form class="form-inline">
                  <span class="bi bi-search"></span>

                  <div class="input-group">
                    
                  <input class="form-control" id="filter" type="search" placeholder="Chercher ..." aria-label="Search" autocomplete="off">
                </form><br>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
