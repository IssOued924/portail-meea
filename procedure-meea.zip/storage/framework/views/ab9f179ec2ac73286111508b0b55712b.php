<div>
    <!-- __BLOCK__ --><?php if($currentPage == PAGECREATEFORM): ?>
        <?php echo $__env->make("livewire.Demandesp0012.create", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?> <!-- __ENDBLOCK__ -->

    <!-- __BLOCK__ --><?php if($currentPage == PAGEEDITFORM): ?>
        <?php echo $__env->make("livewire.Demandesp0012.details", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?> <!-- __ENDBLOCK__ -->

    <!-- __BLOCK__ --><?php if($currentPage == PAGELIST): ?>
        <?php echo $__env->make("livewire.Demandesp0012.liste", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?> <!-- __ENDBLOCK__ -->
</div>
<?php /**PATH D:\DGTD\MEEA\procedure-meea\resources\views/livewire/Demandesp0012/index.blade.php ENDPATH**/ ?>