<div>
    <!-- __BLOCK__ --><?php if($currentPage == PAGECREATEFORM): ?>
        <?php echo $__env->make("livewire.Demandesp008.createDechets", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?> <!-- __ENDBLOCK__ -->

    <!-- __BLOCK__ --><?php if($currentPage == PAGEEDITFORM): ?>
        <?php echo $__env->make("livewire.Demandesp008.details", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?> <!-- __ENDBLOCK__ -->

    <!-- __BLOCK__ --><?php if($currentPage == PAGELIST): ?>
        <?php echo $__env->make("livewire.Demandesp008.liste", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?> <!-- __ENDBLOCK__ -->
</div><?php /**PATH D:\DGTD\MEEA\procedure-meea\resources\views/livewire/Demandesp008/index.blade.php ENDPATH**/ ?>