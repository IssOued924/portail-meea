    <?php $layout->viewContext->mergeIntoNewEnvironment($__env); ?>

    

    <?php $__env->startSection($layout->slotOrSection); ?>
        <?php echo $content; ?>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make($layout->view, $layout->params, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DGTD\MEEA\procedure-meea\storage\framework\views/7470668efe7a821e55d8a2b81149a271.blade.php ENDPATH**/ ?>