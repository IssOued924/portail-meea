<footer id="footer">
    <div class="container">
        <div class="copyright">
            &copy; Copyright <span>MEEA</span> @2023
        </div>
    </div>
</footer<?php /**PATH D:\DGTD\MEEA\procedure-meea\resources\views/components/footer.blade.php ENDPATH**/ ?>