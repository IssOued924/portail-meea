<section id="topbar" class="d-flex align-items-center">
        <div class="container d-flex justify-content-center justify-content-md-between">
            <div class="contact-info d-flex align-items-center"></div>
            <div class="contact-info d-flex align-items-center">
                <i class="bi bi-envelope d-flex align-items-center"><a href="mailto:contact@example.com">procedure@environnement.gov.bf</a></i>
                <i class="bi bi-phone d-flex align-items-center ms-4"><span>+226 25307039</span></i>
            </div>


        </div>
    </section>
<?php /**PATH D:\DGTD\MEEA\procedure-meea\resources\views/components/topbar.blade.php ENDPATH**/ ?>