<button <?php echo e($attributes->merge(['type' => 'submit', 'style' => 'background: #0622f3;
    border: 0;
    border-radius: 50px;
    padding: 10px 24px;
    color: #fff;
    transition: 0.4s;'])); ?>>
    <?php echo e($slot); ?>

</button>

<?php /**PATH D:\DGTD\MEEA\procedure-meea\resources\views/components/primary-button.blade.php ENDPATH**/ ?>