<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Demande extends Model
{
    use HasFactory;

    protected $fillable = [
        "nom",
        "prenom",
        "cnib",
        "adresse",
        "document1",
        "document2",
        "user_id"
        /*
         
        "document2",
        "document3" */
    ];

    public function user(){
        return $this->belongsTo(Demande::class, "user_id", "id");
    }
    
}
