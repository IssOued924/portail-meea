<section id="contact" class="contact">
    <div class="container">

        <div class="row">


            <div class="col">

                <div class="row" id="mycard">
                    <div class="col-lg-4 col-md-6 mb20">
                        <div class="info-box  mb-4">
                            <div class="icon-zone">
                                <a href="#"><img src="assets/img/papiers-icon.png" alt="" class="responsive-img"></a>
                            </div>
                            <h3>
                                <a href="#" class="tooltipped">Demande d'autorisation de transport/transfert d'un animal sauvage ou de
                                    trophées (certificat d'origine)</a>
                            </h3>
                            <p style="text-overflow: ellipsis;">
                            <ul class="list-group " style="list-style-type: none;">
                                <li class=" list-group-item">
                                    <h5> Lorem ipsum dolor sit amet consectetur, adipisicing elit. Voluptatibus natus tenetur enim vel
                                        quis adipisci fugit vitae fugiat, necessitatibus beatae dolore, ullam ipsum voluptatem assumenda
                                        molestiae aliquam voluptatum nam possimus!</h5>
                                </li>
                            </ul>
                            </p>
                            <p><a href="#" data-bs-toggle="modal" data-bs-target="#staticBackdrop">[+] voir plus
                                </a></p>

                        </div>
                    </div>


                    <!-- Modal -->
                    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg modal-dialog-scrollable">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="staticBackdropLabel">Demande d'autorisation de transport/transfert d'un animal sauvage ou de
                                        trophées (certificat d'origine)</h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    Lorem ipsum dolor sit, amet consectetur adipisicing elit. Labore tempore voluptatum porro unde ex ad
                                    numquam
                                    quibusdam cumque ullam iusto, voluptates commodi, sequi illum reiciendis eius tempora, ipsa maxime
                                    corporis.

                                </div>
                                <div class="modal-footer">
                                    <x-secondary-button class="ml-4">
                                        {{ __('Fermer') }}
                                    </x-secondary-button>
                                    <x-primary-button class="ml-4" href="/demandes" wire:navigate>
                                        {{ __('Postuler') }}
                                    </x-primary-button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 mb20">
                        <div class="info-box  mb-4">
                            <div class="icon-zone">
                                <a href="#"><img src="assets/img/papiers-icon.png" alt="" class="responsive-img"></a>
                            </div>
                            <h3>
                                <a class="tooltipped">Demande de licence de concession de zone
                                </a>
                            </h3>
                            <p>
                            <ul class="list-group" style="list-style-type: none">

                                <h5 class="list-goup-item ">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Cumque, magni,
                                    fugiat vel distinctio, ipsum beatae molestiae neque quam sequi debitis numquam. Aperiam maxime,
                                    totam labore libero fugit quasi quibusdam voluptates.</h5>

                                <p><a href="#">[+] voir plus</a></p>
                            </ul>

                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 mb20">
                        <div class="info-box  mb-4">
                            <div class="icon-zone">
                                <a href="#"><img src="assets/img/papiers-icon.png" alt="" class="responsive-img"></a>
                            </div>
                            <h3>
                                <a class="tooltipped">Demandes en ligne des permis pour les services de la faune et de la flore</a>
                            </h3>
                            <p>
                            <ul class="list-group" style="list-style-type: none;">

                                <h5 class="list-group-item "> Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa sequi sit
                                    earum sed a excepturi laboriosam amet! Dolorem ut eius autem illum dolorum iusto commodi ea. Iure
                                    voluptatibus autem voluptates! </h5>

                                <li><a href="#">[+] voir plus</a></li>
                            </ul>
                            </p>
                        </div>

                    </div>


                </div>

                <div class="row">

                    <div class="col-lg-4 col-md-6 mb20">
                        <div class="info-box  mb-4">
                            <div class="icon-zone">
                                <a href="#"><img src="assets/img/papiers-icon.png" alt="" class="responsive-img"></a>
                            </div>
                            <h3>
                                <a class="tooltipped">Demande de permis de circulation ou de permis de coupe (bois et charbon de
                                    bois)</a>
                            </h3>
                            <p>
                            <ul class="list-group" style="list-style-type: none;">

                                <h5 class="list-group-item ">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Magnam fugiat
                                    voluptate ea consequatur quisquam. Architecto quam nostrum repudiandae, tempore illo velit,
                                    assumenda doloremque accusantium deserunt ipsam, perferendis quia quibusdam sunt. </h5>

                                <li><a href="#">[+] voir plus</a></li>
                            </ul>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 mb20">
                        <div class="info-box  mb-4">
                            <div class="icon-zone">
                                <a href="#"><img src="assets/img/papiers-icon.png" alt="" class="responsive-img"></a>
                            </div>
                            <h3>
                                <a class="tooltipped">Paiement de taxes d'aménagement et de gestion des zones concédées</a>
                            </h3>
                            <p>
                            <ul class="list-group" style="list-style-type: none;">

                                <h5 class="list-group-item ">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente ab
                                    velit, corporis optio quis voluptates itaque sunt qui, assumenda maiores praesentium nisi porro?
                                    Ipsa ex velit voluptatem ad omnis ullam?</h5>

                                <li><a href="#">[+] voir plus</a></li>
                            </ul>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 mb20">
                        <div class="info-box  mb-4">
                            <div class="icon-zone">
                                <a href="#"><img src="assets/img/papiers-icon.png" alt="" class="responsive-img"></a>
                            </div>
                            <h3>
                                <a class="tooltipped">Demande d'autorisation de collecte des déchets spéciaux</a>
                            </h3>
                            <p>
                            <ul class="list-group" style="list-style-type: none;">

                                <h5 class="list-group-item ">Lorem ipsum dolor sit amet consectetur adipisicing elit. Dicta blanditiis
                                    neque pariatur beatae! Unde velit ducimus dolores quibusdam quaerat, quo tempore optio
                                    exercitationem provident inventore sit eligendi quisquam odit accusantium.</h5>

                                <li><a href="#">[+] voir plus</a></li>
                            </ul>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 mb20">
                        <div class="info-box  mb-4">
                            <div class="icon-zone">
                                <a href="#"><img src="assets/img/papiers-icon.png" alt="" class="responsive-img"></a>
                            </div>
                            <h3>
                                <a class="tooltipped">Demande d'autorisation d'exercer dans le domaine de la médecine nucléaire
                                    (importation, utilisation, transport et stockage d'équipements)</a>
                            </h3>
                            <p>
                            <ul class="list-group" style="list-style-type: none;">

                                <h5 class="list-group-item ">Lorem ipsum dolor sit amet consectetur adipisicing elit. Possimus culpa
                                    saepe obcaecati totam, molestias tempora aperiam exercitationem libero blanditiis quo, porro, sequi
                                    alias minus cupiditate soluta laboriosam magni fuga molestiae!</h5>

                                <li><a href="#">[+] voir plus</a></li>
                            </ul>
                            </p>
                        </div>
                    </div>


                    <div class="col-lg-4 col-md-6 mb20">
                        <div class="info-box  mb-4">
                            <div class="icon-zone">
                                <a href="#"><img src="assets/img/papiers-icon.png" alt="" class="responsive-img"></a>
                            </div>
                            <h3>
                                <a class="tooltipped">Demande de certificat d'exemption des emballages et sachets plastiques non
                                    biodégradables</a>
                            </h3>
                            <p>
                            <ul class="list-group" style="list-style-type: none;">

                                <h5 class="list-group-item ">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum temporibus
                                    cum facilis odio. Rem aliquid quidem fugit, reprehenderit non reiciendis modi, exercitationem
                                    eligendi velit, culpa distinctio. Amet obcaecati eligendi repellat!</h5>

                                <li><a href="#">[+] voir plus</a></li>
                            </ul>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 mb20">
                        <div class="info-box  mb-4">
                            <div class="icon-zone">
                                <a href="#"><img src="assets/img/papiers-icon.png" alt="" class="responsive-img"></a>
                            </div>
                            <h3>
                                <a class="tooltipped">Demande de certificat d'Homologation des emballages et sachets plastiques
                                    biodégradables</a>
                            </h3>
                            <p>
                            <ul class="list-group" style="list-style-type: none;">

                                <h5 class="list-group-item "> Lorem ipsum, dolor sit amet consectetur adipisicing elit. Aspernatur eum
                                    laborum itaque voluptatem est ad pariatur consequatur modi nihil, voluptas error earum numquam velit
                                    aperiam vel officia ullam minus iusto!</h5>

                                <li><a href="#">[+] voir plus</a></li>
                            </ul>
                            </p>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 mb20">
                        <div class="info-box  mb-4">
                            <div class="icon-zone">
                                <a href="#"><img src="assets/img/papiers-icon.png" alt="" class="responsive-img"></a>
                            </div>
                            <h3>
                                <a class="tooltipped">Octroi de l'agrément technique dans le secteur de l'eau et de l'assainissement
                                    DGRE</a>
                            </h3>
                            <p>
                            <ul class="list-group" style="list-style-type: none;">

                                <h5 class="list-group-item ">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Laboriosam in
                                    nesciunt molestiae eos cupiditate optio quidem, libero nostrum minus alias provident eum sit cum
                                    pariatur delectus? Commodi quos nihil optio! </h5>

                                <li><a href="#">[+] voir plus</a></li>
                            </ul>
                            </p>
                        </div>
                    </div>



                </div>
            </div>
        </div>
    </div>
</section>
</div>