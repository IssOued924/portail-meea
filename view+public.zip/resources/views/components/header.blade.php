<header id="header" class="d-flex align-items-center">
    <div class="container d-flex justify-content-between align-items-center">

        <div class="logo">
            <h1><a href="index.html">Portail MEEA</a></h1>
            <!-- Uncomment below if you prefer to use an image logo -->
            <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
        </div>

        <nav id="navbar" class="navbar">
            <ul>
                @guest
                <li><a class="active" href="index.html">Accueil</a></li>
                <li><a href="about.html">Apropos</a></li>
                <li><a href="services.html">Services</a></li>
                <li><a href="contact.html">Contact</a></li>
                <li><a href="{{ route('register') }}">Connexion</a></li>
                @else
                <li><a class="active" href="index.html">Accueil</a></li>
                <li><a href="about.html">Apropos</a></li>
                <li><a href="services.html">Services</a></li>
                <li><a href="contact.html">Contact</a></li>
                <li class="dropdown">
                    <a><span>
                            <div>{{ Auth::user()->name }}</div>
                        </span> <i class="bi bi-chevron-down"></i>
                    </a>
                    <ul>
                        <li><x-dropdown-link :href="route('profile.edit')">
                            {{ __('Profile') }}
                        </x-dropdown-link></li>
                        <li><form method="POST" action="{{ route('logout') }}">
                            @csrf

                            <x-dropdown-link :href="route('logout')"
                                    onclick="event.preventDefault();
                                                this.closest('form').submit();">
                                {{ __('Se Deconnecter') }}
                            </x-dropdown-link>
                        </form></li>
                    </ul>
                </li>
                @endguest


            </ul>
            <i class="bi bi-list mobile-nav-toggle"></i>
        </nav><!-- .navbar -->

    </div>
</header>